# Smart CO PO AttainX — OBE PO Attainment Dashboard

A Flask-based college project for CO–PO/PSO mapping, direct and indirect attainment calculations, and dashboard generation.

## Stack

- Python 3.12
- Flask 3.0.0
- Pandas 2.1.4
- NumPy 1.26.2

## Run locally

```bash
python3.12 -m venv .venv
source .venv/bin/activate
python -m pip install --upgrade pip
python -m pip install -r requirements.txt
python app.py
```

Open `http://127.0.0.1:5000`.

## Deploy to Vercel

This repository is configured for Vercel's Python/Flask runtime. Import the GitHub repository in Vercel, keep the root directory at the repository root, and allow automatic framework detection. The `vercel.json` file sets the Flask function's maximum duration to 60 seconds.

Configure these environment variables in Vercel for Production (and Preview if needed):

| Variable | Purpose |
|---|---|
| `SECRET_KEY` | Long, randomly generated Flask session secret |
| `TEACHER_PASSWORD` | Shared password for the teacher accounts currently listed in `app.py` |
| `ADMIN_EMAILS` | Optional comma-separated administrator email addresses |
| `ADMIN_PASSWORD` | Administrator password; required when `ADMIN_EMAILS` is set |

Generate a secret with:

```bash
python -c "import secrets; print(secrets.token_urlsafe(48))"
```

Do not commit `.env` files or real credentials. The application limits upload requests to 4 MB to remain within Vercel's function request-body limit.

## Data and storage note

Uploaded CSVs are processed in the request and are not stored as a permanent student-record database. Vercel function storage is ephemeral; use an external storage/database service before extending the application to retain student data.

## New PO and practical-only evaluation

For the **New POs (from 2025-26)** format, the survey/indirect upload is not used. Direct CO attainment (derived from ESE and the CO-aligned CCE columns) contributes 100% to the final CO and PO attainment. The PO attainment percentage is calculated as `Final PO Attainment / PO Mapping × 100`.

The **Only Practical** course evaluation type uses the practical direct-mark template (`ESE`, `CCE1`–`CCE5`) and the New PO mapping template. Where the course's assessment scheme has ESE and CCE, the existing New PO direct formula is retained (75% ESE + 25% CO-aligned CCE). For CCE-only practical courses, each CO uses its corresponding CCE column. No survey file is required.

TY B Tech course choices are based on the uploaded AY 2026-27 Instrumentation and Control Engineering Course Pattern 2024 syllabus. The semester structure is used where the PDF contains conflicting course-code references; see the implementation notes for flagged inconsistencies.


### TY syllabus code and title notes

The TY dropdown follows the Semester V and Semester VI curriculum-structure tables in the uploaded AY 2026-27 syllabus where the index or detailed course pages disagree. The PDF contains these conflicts, which should be confirmed against the department's final ERP/course master before official use:

- Elective I theory: `IC1240PE507` in the index/semester table versus `IC1240PC507` on its detailed course page. The dropdown uses `IC1240PE507`.
- Elective I Lab: `IC1240PE508` in the index versus `IC1240PC508` in the Semester V structure. The dropdown uses `IC1240PC508`.
- MDM3 Process Control: `IC1240MD509` in the index/semester structure versus `IC1240OE509` on the detailed page. The dropdown uses `IC1240MD509`.
- Semester V Non-Credit Course 6: `IC1240NC512` in the semester structure versus `IC1240NC612` on its detailed page. The dropdown uses `IC1240NC512`.
- Embedded & IoT Systems Design Lab: `IC1240PE608` in the index versus `IC1240PC608` in the Semester VI structure. The dropdown uses `IC1240PC608`.
- Semester VI Non-Credit Course 7 is called “Smart Plant Instrumentation” in the index and “Smart Process Instrumentation” in the Semester VI structure. The dropdown uses the semester-structure title “Smart Process Instrumentation”.

The protected ERP pages were not accessible without an authorised session, so these records have not been independently reconciled against the ERP.

For **Only Practical**, use the practical mapping template so the CO Practical Statement column is populated. The backend displays that practical CO statement in the practical CO summary. New-PO submissions do not accept or require an indirect survey file; do not upload one for this format.
