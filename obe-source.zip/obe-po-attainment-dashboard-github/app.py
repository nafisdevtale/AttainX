from flask import Flask, render_template, request, session, redirect, url_for, Response
import pandas as pd
import numpy as np
import traceback
import re
import os
import io
import csv
from datetime import timedelta

# Vercel packages this Flask application as a single function. Serve the
# bundled templates and static resources from the extracted application folder.
app = Flask(__name__, static_folder='public/static', static_url_path='/static')
# Vercel Functions reject request bodies larger than 4.5 MB. Keep the
# application limit below that platform limit to leave room for multipart headers.
app.config['MAX_CONTENT_LENGTH'] = 4 * 1024 * 1024  # 4 MB total request limit
_is_vercel = bool(os.environ.get('VERCEL'))
_secret_key = os.environ.get('SECRET_KEY')
if _is_vercel and not _secret_key:
    raise RuntimeError('Missing SECRET_KEY environment variable in Vercel project settings.')
app.secret_key = _secret_key or 'local-development-only-change-before-deployment'
app.config['PERMANENT_SESSION_LIFETIME'] = timedelta(minutes=30)
app.config['SESSION_REFRESH_EACH_REQUEST'] = True
app.config['SESSION_COOKIE_HTTPONLY'] = True
app.config['SESSION_COOKIE_SAMESITE'] = 'Lax'
app.config['SESSION_COOKIE_SECURE'] = _is_vercel

# ===========================================================================
# SECURITY SYSTEM & ACCOUNTS
# ===========================================================================
_default_admin_emails = '' if _is_vercel else 'admin_email@example.com'
ADMIN_EMAILS = [
    email.strip().lower()
    for email in os.environ.get('ADMIN_EMAILS', _default_admin_emails).split(',')
    if email.strip()
]
ADMIN_PASSWORD = os.environ.get(
    'ADMIN_PASSWORD', '' if _is_vercel else 'ENTER_ADMIN_PASSWORD_HERE'
)

TEACHER_ACCOUNTS = {
    "hod_instrumentation@dypcoeakurdi.ac.in": "Dr. B. B. Musmade",
    "nvmane@dypcoeakurdi.ac.in": "Mr. N. V. Mane",
    "rrsangitrao@dypcoeakurdi.ac.in": "Ms. R. R. Sangitrao",
    "aautikar@dypcoeakurdi.ac.in": "Mrs. A. A Utikar",
    "arkesti@dypcoeakurdi.ac.in": "Mrs. A. R. Kesti",
    "yhpatil@dypcoeakurdi.ac.in": "Dr. Y. H. Patil",
    "gtiwari@dypcoeakurdi.ac.in": "Garima Tiwari",
    "vvyerande@dypcoeakurdi.ac.in": "V. V. Yerande",
    "asnandagaon@dypcoeakurdi.ac.in": "Mrs. A. S. Nandagaon"
}
TEACHER_PASSWORD = os.environ.get('TEACHER_PASSWORD', '' if _is_vercel else 'Instru')

# ===========================================================================
# ENCODING-SAFE CSV READER (UTF-8-SIG -> UTF-8 -> CP1252)
# ===========================================================================
SUPPORTED_CSV_ENCODINGS = ("utf-8-sig", "utf-8", "cp1252")


def decode_csv_content(file_or_source, file_label=None):
    filename = file_label
    if not filename:
        filename = getattr(file_or_source, "filename", None)
    if not filename and hasattr(file_or_source, "name"):
        filename = getattr(file_or_source, "name")
    if not filename:
        filename = "uploaded CSV file"

    raw_bytes = None

    if hasattr(file_or_source, "stream"):
        stream = file_or_source.stream
        try:
            stream.seek(0)
        except Exception:
            pass
        raw_bytes = stream.read()
        try:
            stream.seek(0)
        except Exception:
            pass
        try:
            file_or_source.seek(0)
        except Exception:
            pass
    elif hasattr(file_or_source, "seek") and hasattr(file_or_source, "read"):
        if isinstance(file_or_source, io.StringIO):
            return file_or_source.getvalue()
        try:
            file_or_source.seek(0)
        except Exception:
            pass
        raw_bytes = file_or_source.read()
        try:
            file_or_source.seek(0)
        except Exception:
            pass
    elif isinstance(file_or_source, (bytes, bytearray)):
        raw_bytes = bytes(file_or_source)
    elif isinstance(file_or_source, str):
        if os.path.isfile(file_or_source):
            filename = os.path.basename(file_or_source)
            with open(file_or_source, "rb") as f:
                raw_bytes = f.read()
        else:
            return file_or_source
    else:
        try:
            from pathlib import Path
            if isinstance(file_or_source, Path) and file_or_source.is_file():
                filename = file_or_source.name
                raw_bytes = file_or_source.read_bytes()
        except Exception:
            pass

    if raw_bytes is None:
        raise ValueError(f"Unable to read content from '{filename}': Unrecognized input type.")

    for encoding in SUPPORTED_CSV_ENCODINGS:
        try:
            return raw_bytes.decode(encoding)
        except (UnicodeDecodeError, LookupError):
            continue

    raise ValueError(
        f"Unable to decode '{filename}': invalid encoding. Supported encodings are UTF-8, "
        f"UTF-8 with BOM, and Windows-1252 (CP1252). Please ensure the file is saved with a supported encoding."
    )


_orig_pd_read_csv = pd.read_csv


def safe_read_csv(file_or_source, *args, **kwargs):
    file_label = kwargs.pop("file_label", None)
    if "encoding" in kwargs:
        try:
            return _orig_pd_read_csv(file_or_source, *args, **kwargs)
        except (UnicodeDecodeError, UnicodeError):
            kwargs.pop("encoding", None)

    decoded_text = decode_csv_content(file_or_source, file_label=file_label)
    return _orig_pd_read_csv(io.StringIO(decoded_text), *args, **kwargs)


pd.read_csv = safe_read_csv

# ===========================================================================
# HELPER FUNCTIONS
# ===========================================================================

def parse_mapping_value(v):
    if pd.isna(v): return None
    v_str = str(v).strip().lower()
    if v_str in ['', '-', 'nan', 'none', 'na']: return None
    try:
        val_f = float(v_str)
        if val_f in [0.0, 1.0, 2.0, 3.0]:
            return val_f
    except ValueError:
        pass
    return None

def excel_round(x, digits=0):
    if pd.isna(x) or np.isinf(x):
        return np.nan
    factor = 10 ** digits
    return float(np.floor(x * factor + 0.5) / factor)

def compute_direct_attainment(col, cut_low, cut_mid, cut_high):
    mx = col.dropna().max()
    if pd.isna(mx) or mx == 0: return 0.0
    t_low  = excel_round(mx * cut_low)
    t_mid  = excel_round(mx * cut_mid)
    t_high = excel_round(mx * cut_high)
    arr = col.dropna().astype(float).values
    n = len(arr)
    if n == 0: return 0.0
    n0 = int(np.sum(arr < t_low))
    n1 = int(np.sum(arr >= t_low)) - int(np.sum(arr > t_mid))
    n2 = int(np.sum(arr > t_mid))  - int(np.sum(arr > t_high))
    n3 = int(np.sum(arr > t_high))
    return float((n0 * 0 + n1 * 1 + n2 * 2 + n3 * 3) / n)

def compute_survey_attainment(col, cut_low, cut_mid, cut_high):
    return compute_direct_attainment(col, cut_low, cut_mid, cut_high)

def safe_avg(*args):
    valid = [a for a in args if pd.notna(a)]
    return float(np.mean(valid)) if valid else 0.0

METADATA_COLUMN_PATTERNS = [
    r'^(?:SR\.?\s*NO\.?|S\.?\s*NO\.?|SERIAL\s*NO\.?|SR_NO)$',
    r'^(?:NAME|STUDENT\s*NAME|CANDIDATE\s*NAME)$',
    r'^(?:ROLL\s*NO\.?|ROLL\s*NUMBER|REG\.?\s*NO\.?|PRN|UID|ID)$',
    r'^(?:TIMESTAMP|TIME|DATE)$',
    r'^(?:EMAIL|EMAIL\s*ADDRESS)$',
    r'^(?:FEEDBACK|COMMENT|COMMENTS|REMARK|REMARKS|SUGGESTION|SUGGESTIONS)$',
    r'^(?:CLASS|DIVISION|DIV|BRANCH|YEAR|SEMESTER|SEM)$',
]


def is_metadata_column(col_name):
    norm = str(col_name).strip().upper()
    return any(re.match(p, norm) for p in METADATA_COLUMN_PATTERNS)


def is_candidate_co_column(col_name):
    s = str(col_name).strip().upper()
    if not s or s.startswith("UNNAMED") or is_metadata_column(s):
        return False
    if re.search(r'\bCO\s*[-_.]?\s*\d+', s):
        return True
    if re.search(r'\bC\s*[-_.]?\s*\d+', s):
        return True
    if re.search(r'\bCOURSE\s*OUTCOME\s*[-_.]?\s*\d+', s):
        return True
    if re.match(r'^C[A-Z0-9_-]*[._-]?\d+$', s):
        return True
    return False


def normalize_co_key(s):
    return re.sub(r'[^A-Z0-9]', '', str(s).strip().upper())


def extract_co_index(s):
    s_clean = str(s).strip().upper()
    m = re.search(r'\b(?:CO|COURSE\s*OUTCOME)\s*[-_.]?\s*(\d+)', s_clean)
    if m:
        return int(m.group(1))
    m = re.search(r'\bC[A-Z0-9_-]*[._-](\d+)', s_clean)
    if m:
        return int(m.group(1))
    m = re.search(r'\bC\s*[-_.]?\s*(\d+)', s_clean)
    if m:
        return int(m.group(1))
    m = re.search(r'(\d+)\s*$', s_clean)
    if m:
        return int(m.group(1))
    m = re.search(r'(\d+)', s_clean)
    if m:
        return int(m.group(1))
    return None


def find_survey_header_row(rows):
    candidates = []
    for idx, row in enumerate(rows):
        co_count = sum(1 for val in row if is_candidate_co_column(val))
        if co_count > 0:
            candidates.append((idx, co_count))
    if not candidates:
        raise ValueError(
            "The Survey Sheet must contain Course Outcome (CO) rating columns (e.g., C301.1, CO1, CO 1, etc.)."
        )
    return max(candidates, key=lambda x: (x[1], -x[0]))[0]


def align_survey_columns(survey_columns, mapped_cos):
    number_of_cos = len(mapped_cos)
    if number_of_cos == 0:
        raise ValueError("No CO statements were found in the mapping sheet.")

    candidate_cols = [c for c in survey_columns if is_candidate_co_column(c)]
    if not candidate_cols:
        non_meta = [
            c for c in survey_columns
            if not is_metadata_column(c) and not str(c).strip().upper().startswith("UNNAMED")
        ]
        if len(non_meta) == number_of_cos:
            candidate_cols = non_meta

    if len(candidate_cols) < number_of_cos:
        missing_co = mapped_cos[len(candidate_cols)] if len(candidate_cols) < len(mapped_cos) else mapped_cos[-1]
        cand_indices = {extract_co_index(c) for c in candidate_cols if extract_co_index(c) is not None}
        for co in mapped_cos:
            idx = extract_co_index(co)
            if idx is not None and idx not in cand_indices:
                missing_co = co
                break
        raise ValueError(
            f"The Survey Sheet contains {len(candidate_cols)} CO columns, but the mapping sheet has {number_of_cos} COs. "
            f"Missing survey column for mapped CO: {missing_co}."
        )

    # Strategy 1: Exact or Normalized Code Match
    norm_survey_map = {normalize_co_key(c): c for c in candidate_cols}
    exact_matches = []
    all_exact = True
    for co in mapped_cos:
        k = normalize_co_key(co)
        if k in norm_survey_map:
            exact_matches.append(norm_survey_map[k])
        else:
            all_exact = False
            break
    if all_exact and len(exact_matches) == number_of_cos:
        return exact_matches

    # Strategy 2: Match by CO index (handles different prefixes, e.g. C410A.1 vs C301.1 or CO1)
    col_by_index = {}
    for c in candidate_cols:
        idx = extract_co_index(c)
        if idx is not None and idx not in col_by_index:
            col_by_index[idx] = c

    index_matches = []
    all_indexed = True
    missing_co_by_index = None
    for co in mapped_cos:
        idx = extract_co_index(co)
        if idx is not None and idx in col_by_index:
            index_matches.append(col_by_index[idx])
        else:
            all_indexed = False
            missing_co_by_index = co
            break

    if all_indexed and len(index_matches) == number_of_cos:
        return index_matches

    # Strategy 3: Positional matching
    # Positional matching is permitted only when the survey and mapping contain exactly the same number of COs
    if len(candidate_cols) == number_of_cos:
        return list(candidate_cols)

    # If alignment failed
    if missing_co_by_index:
        raise ValueError(f"Survey column for mapped CO '{missing_co_by_index}' was not found in the Survey Sheet.")
    raise ValueError(
        f"Could not unambiguously match survey columns to mapped COs ({len(candidate_cols)} candidate columns for {number_of_cos} mapped COs)."
    )


def process_indirect_survey(indirect_file, mapped_cos, base_threshold):
    if indirect_file is None:
        raise ValueError("Survey Sheet (Indirect Ratings) is required.")

    survey_name = getattr(indirect_file, "filename", None)
    if not survey_name and hasattr(indirect_file, "name"):
        survey_name = getattr(indirect_file, "name")
    if not survey_name:
        survey_name = "Survey Sheet"

    content = decode_csv_content(indirect_file, file_label=survey_name)
    rows = list(csv.reader(io.StringIO(content)))
    if not rows or not any(any(str(c).strip() for c in r) for r in rows):
        raise ValueError("The uploaded Survey Sheet is empty.")

    header_idx = find_survey_header_row(rows)
    df_survey = _orig_pd_read_csv(io.StringIO(content), header=header_idx)
    df_survey.columns = df_survey.columns.astype(str).str.strip().str.upper()
    df_survey = df_survey.loc[:, ~df_survey.columns.astype(str).str.contains("^UNNAMED", case=False, na=False)]

    aligned_columns = align_survey_columns(df_survey.columns, mapped_cos)

    for col in aligned_columns:
        df_survey[col] = pd.to_numeric(df_survey[col], errors="coerce")

    df_survey_clean = df_survey.dropna(subset=aligned_columns, how="all")
    if df_survey_clean.empty:
        raise ValueError("The Survey Sheet contains no valid student responses.")

    d_high = float(base_threshold) / 100.0
    d_mid = (float(base_threshold) - 15.0) / 100.0
    d_low = (float(base_threshold) - 30.0) / 100.0
    s_high = d_high - 0.10
    s_mid = d_mid - 0.10
    s_low = d_low - 0.10

    indirect_values = [
        compute_survey_attainment(df_survey_clean[col], s_low, s_mid, s_high)
        for col in aligned_columns
    ]

    return indirect_values, df_survey_clean


def extract_cos_from_mapping(mapping_source):
    content = decode_csv_content(mapping_source, file_label="mapping_file")
    rows = list(csv.reader(io.StringIO(content)))
    header_idx = None
    for idx, row in enumerate(rows):
        if any("CO CODE" in str(c).upper() for c in row):
            header_idx = idx
            break
    if header_idx is None:
        raise ValueError("Could not find 'CO Codes' column in the mapping sheet.")

    co_col_idx = next(i for i, c in enumerate(rows[header_idx]) if "CO" in str(c).upper())
    co_codes = []
    for row in rows[header_idx + 1:]:
        if row and len(row) > co_col_idx:
            val = str(row[co_col_idx]).strip()
            val_u = val.upper()
            if not val or val_u in ("-", "NAN", "NONE"):
                continue
            if any(kw in val_u for kw in ("TOTAL", "TARGET", "AVERAGE", "WEIGHT", "PRACTICAL", "STATEMENT")):
                continue
            if val_u.startswith("C") or re.match(r"^[A-Z0-9_-]+[._-]?\d+$", val_u):
                co_codes.append(val)
    if not co_codes:
        raise ValueError("No Course Outcomes found in the mapping sheet.")
    return co_codes


def generate_survey_template_csv(co_codes):
    if not co_codes:
        raise ValueError("At least one Course Outcome (CO) is required to generate a survey template.")
    pad = "," * len(co_codes)
    line1 = f",Survey for Indirect Attainment Only{pad}"
    line2 = "Sr. No.,Name ," + ",".join(co_codes)
    return f"\ufeff{line1}\r\n{line2}\r\n"

# ===========================================================================
# ALGORITHM 1 & 2: ORIGINAL POS (UNCHANGED)
# ===========================================================================
def calculate_dashboard_old_pos(mapping_file, direct_file, indirect_file, base_threshold, has_practical, exclude_po12=False):
    df_map_raw = safe_read_csv(mapping_file, header=None)
    header_idx = None
    for idx, row in df_map_raw.iterrows():
        if row.astype(str).str.contains('CO Codes|CO Code', case=False, na=False).any():
            header_idx = idx
            break
    if header_idx is None: raise ValueError("Could not find 'CO Codes' row in mapping file")

    mapping_file.seek(0)
    df_map = safe_read_csv(mapping_file, header=header_idx)
    df_map.columns = df_map.columns.astype(str).str.strip().str.upper()
    co_col = [col for col in df_map.columns if 'CO' in str(col)][0]

    p_col_check = [c for c in df_map.columns if 'PRACTICAL' in str(c).upper() and 'STATEMENT' in str(c).upper()]
    if has_practical == 'yes' and not p_col_check:
        raise ValueError("Data Mismatch! Practical template required.")
    if has_practical == 'no' and p_col_check:
        raise ValueError("Data Mismatch! Theory template required.")

    df_map[co_col] = df_map[co_col].astype(str).str.strip().str.upper()
    theory_rows = df_map[df_map[co_col].str.startswith('C', na=False)]
    num_theory_cos = len(theory_rows) if len(theory_rows) > 0 else 6 

    df_direct_raw = safe_read_csv(direct_file, header=None)
    header_idx_direct = None
    for idx, row in df_direct_raw.iterrows():
        row_str = row.astype(str).str.lower()
        if row_str.str.contains('ise').any() and row_str.str.contains('ese').any():
            header_idx_direct = idx
            break
            
    if header_idx_direct is None: raise ValueError("Your Direct marks CSV must contain columns named 'ISE' and 'ESE'.")
        
    direct_file.seek(0)
    df_direct = safe_read_csv(direct_file, header=header_idx_direct)
    df_direct.columns = df_direct.columns.astype(str).str.strip().str.lower()

    has_pr_col = any(c.strip() == 'pr' for c in df_direct.columns)
    if has_practical == 'yes' and not has_pr_col:
        raise ValueError("Data Mismatch! Practical Direct Marks file required.")
    if has_practical == 'no' and has_pr_col:
        raise ValueError("Data Mismatch! Theory Direct Marks file required.")

    ise_col = [c for c in df_direct.columns if 'ise' in c]
    ese_col = [c for c in df_direct.columns if 'ese' in c]

    ise_series = pd.to_numeric(df_direct[ise_col[0]], errors='coerce')
    ese_series = pd.to_numeric(df_direct[ese_col[0]], errors='coerce')

    d_high = float(base_threshold) / 100.0
    d_mid  = (float(base_threshold) - 15.0) / 100.0
    d_low  = (float(base_threshold) - 30.0) / 100.0

    dir_vals_list = []
    if has_practical == 'no':
        ise_half    = ise_series.apply(lambda v: excel_round(v / 2, 0))
        ese_qtr     = ese_series.apply(lambda v: excel_round(v / 4, 0))
        ut1         = (30 * ise_series) / 50
        ut1_half    = ut1.apply(lambda v: excel_round(v / 2, 0))
        ut2         = ut1 + 2
        ut2_half    = ut2.apply(lambda v: excel_round(v / 2, 0))
        prelims     = (ese_series + ise_half) * 70 / 100
        prelims_qtr = prelims.apply(lambda v: excel_round(v / 4, 0))

        d34, f34 = compute_direct_attainment(ise_half, d_low, d_mid, d_high), compute_direct_attainment(ese_qtr, d_low, d_mid, d_high)
        h34, j34 = compute_direct_attainment(ut1_half, d_low, d_mid, d_high), compute_direct_attainment(ut2_half, d_low, d_mid, d_high)
        l34 = compute_direct_attainment(prelims_qtr, d_low, d_mid, d_high)

        for i in range(num_theory_cos):
            if i < 2: val = safe_avg(d34) * 0.75 + safe_avg(h34, l34) * 0.25
            elif i < 4: val = safe_avg(f34) * 0.75 + safe_avg(j34, l34) * 0.25
            else: val = safe_avg(f34) * 0.75 + safe_avg(l34) * 0.25
            dir_vals_list.append(val)
    else:
        pr_series       = pd.to_numeric(df_direct[[c for c in df_direct.columns if c.strip() == 'pr'][0]], errors='coerce')
        ut1_series_raw  = pd.to_numeric(df_direct[[c for c in df_direct.columns if c.strip() == 'ut1'][0]], errors='coerce')
        ut2_series_raw  = pd.to_numeric(df_direct[[c for c in df_direct.columns if c.strip() == 'ut2'][0]], errors='coerce')
        pre_series_raw  = pd.to_numeric(df_direct[[c for c in df_direct.columns if 'prelim' in c.strip()][0]], errors='coerce')

        ise_half    = ise_series.apply(lambda v: excel_round(v / 2, 0))
        ese_qtr     = ese_series.apply(lambda v: excel_round(v / 4, 0))
        pr_eighth   = pr_series.apply(lambda v: excel_round(v / 8, 0))
        ut1_half    = ut1_series_raw.apply(lambda v: excel_round(v / 2, 0))
        ut2_half    = ut2_series_raw.apply(lambda v: excel_round(v / 2, 0))
        prelims_qtr = pre_series_raw.apply(lambda v: excel_round(v / 4, 0))

        d76 = compute_direct_attainment(ise_half, d_low, d_mid, d_high)  
        f76 = compute_direct_attainment(ese_qtr, d_low, d_mid, d_high)  
        h76 = compute_direct_attainment(pr_eighth, d_low, d_mid, d_high)  
        j76 = compute_direct_attainment(ut1_half, d_low, d_mid, d_high)  
        l76 = compute_direct_attainment(ut2_half, d_low, d_mid, d_high)  
        n76 = compute_direct_attainment(prelims_qtr, d_low, d_mid, d_high)  

        for i in range(num_theory_cos):
            if i < 2: val = safe_avg(d76, h76) * 0.75 + safe_avg(j76, n76) * 0.25
            elif i < 4: val = safe_avg(f76, h76) * 0.75 + safe_avg(l76, n76) * 0.25
            else: val = safe_avg(f76, h76) * 0.75 + safe_avg(n76) * 0.25
            dir_vals_list.append(val)

    dir_vals = np.array(dir_vals_list)

    mapped_cos = theory_rows[co_col].astype(str).str.strip().tolist()[:num_theory_cos]
    if len(mapped_cos) == 0:
        mapped_cos = [f"CO{i+1}" for i in range(num_theory_cos)]

    ind_vals_list, df_indirect = process_indirect_survey(
        indirect_file, mapped_cos, base_threshold
    )
    ind_vals = np.array(ind_vals_list)

    po_pso_columns = ['PO1','PO2','PO3','PO4','PO5','PO6','PO7','PO8','PO9','PO10','PO11','PO12','PSO1','PSO2','PSO3']
    if exclude_po12 and 'PO12' in po_pso_columns:
        po_pso_columns.remove('PO12')

    dashboard_results = []
    
    for col in po_pso_columns:
        if col not in df_map.columns: continue
        
        raw_vals = theory_rows[col].values[:num_theory_cos]
        weights_list = []
        applicable_cos_count = 0
        
        for v in raw_vals:
            parsed_val = parse_mapping_value(v)
            if parsed_val is not None and parsed_val > 0:
                weights_list.append(parsed_val)
                applicable_cos_count += 1
            else:
                weights_list.append(0.0)

        weights_array = np.array(weights_list)
        if len(weights_array) < num_theory_cos:
            weights_array = np.pad(weights_array, (0, num_theory_cos - len(weights_array)))

        sum_weights = np.sum(weights_array)

        if applicable_cos_count == 0 or sum_weights <= 0:
            dashboard_results.append({'po': col, 'target': '0.00', 'direct': '0.00', 'indirect': '0.00', 'final': '0.00', 'percentage': '0.00'})
            continue

        target      = sum_weights / applicable_cos_count
        direct_po   = np.sum(dir_vals  * weights_array) / sum_weights if sum_weights > 0 else 0
        indirect_po = np.sum(ind_vals  * weights_array) / sum_weights if sum_weights > 0 else 0

        final_po   = (0.8 * direct_po) + (0.2 * indirect_po)
        percentage = (final_po / target) * 100 if target > 0 else 0

        dashboard_results.append({
            'po': col, 'target': f"{target:.2f}", 'direct': f"{direct_po  * 0.8:.4f}",
            'indirect': f"{indirect_po * 0.2:.4f}", 'final': f"{final_po:.4f}", 'percentage': f"{percentage:.2f}"
        })

    co_statements, practical_statements = extract_statements(df_map, co_col, num_theory_cos, has_practical, po_pso_columns, dir_vals, ind_vals)
    return dashboard_results, df_map, df_direct, df_indirect, co_statements, practical_statements

def calculate_dashboard_new_pos(mapping_file, direct_file, base_threshold, has_practical, practical_only=False):
    """New-PO direct-only calculation (no indirect survey upload).

    Standard theory/practical uses the existing 75% ESE + 25% CCE rule.
    Practical-only courses use the same rule when ESE is present. For CCE-only
    courses, each CO uses its corresponding CCE column (CCE1 for CO1, etc.).
    Direct attainment is 100% of the final CO and PO result in this format.
    """
    df_map_raw = safe_read_csv(mapping_file, header=None)
    header_idx = None
    for idx, row in df_map_raw.iterrows():
        if row.astype(str).str.contains('CO Codes|CO Code', case=False, na=False).any():
            header_idx = idx
            break

    mapping_file.seek(0)
    df_map = safe_read_csv(mapping_file, header=header_idx if header_idx is not None else 0)
    df_map.columns = df_map.columns.astype(str).str.strip().str.upper()
    co_candidates = [col for col in df_map.columns if 'CO' in str(col)]
    if not co_candidates:
        raise ValueError("The mapping sheet must contain a 'CO Codes' column.")
    co_col = co_candidates[0]

    df_map[co_col] = df_map[co_col].astype(str).str.strip().str.upper()
    theory_rows = df_map[df_map[co_col].str.startswith('C', na=False)]
    num_theory_cos = len(theory_rows) if len(theory_rows) > 0 else 6

    df_direct_raw = safe_read_csv(direct_file, header=None)
    d_header = None
    for idx, row in df_direct_raw.iterrows():
        row_str = row.astype(str).str.strip().str.lower()
        has_cce1 = row_str.str.fullmatch(r'cce1').any()
        has_ese = row_str.str.fullmatch(r'ese').any()
        if has_cce1 and (practical_only or has_ese):
            d_header = idx
            break

    if d_header is None:
        if practical_only:
            raise ValueError("The Only Practical marks CSV must contain CCE1 to CCE5 columns. ESE is optional for CCE-only courses.")
        raise ValueError("Your New PO Direct marks CSV must contain columns named 'ESE' and 'CCE1'.")

    direct_file.seek(0)
    df_direct = safe_read_csv(direct_file, header=d_header)
    df_direct.columns = df_direct.columns.astype(str).str.strip().str.lower()

    ese_col = [c for c in df_direct.columns if c == 'ese']
    ese_series = pd.to_numeric(df_direct[ese_col[0]], errors='coerce') if ese_col else pd.Series(dtype=float)

    # The New-PO CCE columns are aligned by CO: CCE1 -> CO1, CCE2 -> CO2, etc.
    cce_series_by_number = {}
    for i in range(1, 10):
        c_col = [c for c in df_direct.columns if c == f'cce{i}']
        if c_col:
            cce_series_by_number[i] = pd.to_numeric(df_direct[c_col[0]], errors='coerce')
    if not cce_series_by_number:
        raise ValueError("The Direct marks CSV must contain at least one CCE column (CCE1, CCE2, etc.).")

    has_pr_col = any(c.strip() == 'pr' for c in df_direct.columns)
    if not practical_only:
        if has_practical == 'yes' and not has_pr_col:
            raise ValueError("Data Mismatch! Practical Direct Marks file required for New POs (Missing 'PR').")
        if has_practical == 'no' and has_pr_col:
            raise ValueError("Data Mismatch! Theory Direct Marks file required for New POs.")

    d_high = base_threshold / 100.0
    d_mid = (base_threshold - 15) / 100.0
    d_low = (base_threshold - 30) / 100.0

    ese_att = compute_direct_attainment(ese_series, d_low, d_mid, d_high) if not ese_series.dropna().empty else None
    cce_atts = {
        number: compute_direct_attainment(series, d_low, d_mid, d_high)
        for number, series in cce_series_by_number.items()
    }
    avg_cce_att = safe_avg(*cce_atts.values()) if cce_atts else 0.0

    dir_vals_list = []
    if practical_only and ese_att is None:
        # CCE-only subjects: align CCE1 with CO1, CCE2 with CO2, etc.
        dir_vals_list = [cce_atts.get(i + 1, avg_cce_att) for i in range(num_theory_cos)]
    else:
        if ese_att is None:
            raise ValueError("An ESE column is required for this course's New-PO assessment scheme.")
        if practical_only or has_practical == 'no':
            for i in range(num_theory_cos):
                cce_val = cce_atts.get(i + 1, avg_cce_att)
                dir_vals_list.append((ese_att * 0.75) + (cce_val * 0.25))
        else:
            pr_col = [c for c in df_direct.columns if c == 'pr']
            pr_series = pd.to_numeric(df_direct[pr_col[0]], errors='coerce')
            pr_att = compute_direct_attainment(pr_series, d_low, d_mid, d_high)
            for i in range(num_theory_cos):
                cce_val = cce_atts.get(i + 1, avg_cce_att)
                dir_vals_list.append((safe_avg(ese_att, pr_att) * 0.75) + (cce_val * 0.25))

    dir_vals = np.array(dir_vals_list, dtype=float)
    ind_vals = np.zeros(num_theory_cos, dtype=float)
    df_indirect = pd.DataFrame()

    po_pso_columns = ['PO1', 'PO2', 'PO3', 'PO4', 'PO5', 'PO6', 'PO7', 'PO8', 'PO9', 'PO10', 'PO11', 'PO12', 'PSO1', 'PSO2', 'PSO3']
    dashboard_results = []

    for col in po_pso_columns:
        if col not in df_map.columns:
            continue

        raw_vals = theory_rows[col].values[:num_theory_cos]
        weights_list = []
        applicable_cos_count = 0
        for value in raw_vals:
            parsed_val = parse_mapping_value(value)
            if parsed_val is not None and parsed_val > 0:
                weights_list.append(parsed_val)
                applicable_cos_count += 1
            else:
                weights_list.append(0.0)

        weights_array = np.array(weights_list, dtype=float)
        if len(weights_array) < num_theory_cos:
            weights_array = np.pad(weights_array, (0, num_theory_cos - len(weights_array)))

        sum_weights = float(np.sum(weights_array))

        if applicable_cos_count == 0 or sum_weights <= 0:
            dashboard_results.append({
                'po': col, 'target': '0.00', 'direct': '0.0000',
                'indirect': '0.0000', 'final': '0.0000', 'percentage': '0.00'
            })
            continue

        target = sum_weights / applicable_cos_count
        direct_po = float(np.sum(dir_vals * weights_array) / sum_weights) if sum_weights > 0 else 0.0
        final_po = direct_po  # Option B: direct attainment contributes 100%.
        percentage = (final_po / target) * 100.0 if target > 0 else 0.0

        dashboard_results.append({
            'po': col,
            'target': f"{target:.2f}",
            'direct': f"{direct_po:.4f}",
            'indirect': '0.0000',
            'final': f"{final_po:.4f}",
            'percentage': f"{percentage:.2f}"
        })

    co_statements, practical_statements = extract_statements(
        df_map, co_col, num_theory_cos,
        'no' if practical_only else has_practical,
        po_pso_columns, dir_vals, ind_vals,
        direct_only=True,
        practical_only=practical_only
    )
    return dashboard_results, df_map, df_direct, df_indirect, co_statements, practical_statements


# ===========================================================================
# ALGORITHM 3: NEW PROJECT / TERMWORK / SEMINAR CALCULATION
# ===========================================================================
def calculate_dashboard_project(mapping_file, direct_file, base_threshold, academic_year):
    df_map_raw = safe_read_csv(mapping_file, header=None)
    header_idx = None
    for idx, row in df_map_raw.iterrows():
        if row.astype(str).str.contains('CO Codes|CO Code', case=False, na=False).any():
            header_idx = idx
            break
    if header_idx is None: raise ValueError("Could not find 'CO Codes' row in mapping file")

    mapping_file.seek(0)
    df_map = safe_read_csv(mapping_file, header=header_idx)
    df_map.columns = df_map.columns.astype(str).str.strip().str.upper()
    co_col = [col for col in df_map.columns if 'CO' in str(col)][0]

    df_map[co_col] = df_map[co_col].astype(str).str.strip().str.upper()
    theory_rows = df_map[df_map[co_col].str.startswith('C', na=False)]
    num_theory_cos = len(theory_rows) if len(theory_rows) > 0 else 6 

    df_direct_raw = safe_read_csv(direct_file, header=None)
    d_header = 0
    for idx, row in df_direct_raw.iterrows():
        row_str = row.astype(str).str.lower()
        if row_str.str.contains('ese|or|review|tw').any():
            d_header = idx
            break
            
    direct_file.seek(0)
    df_direct = safe_read_csv(direct_file, header=d_header)
    df_direct.columns = df_direct.columns.astype(str).str.strip().str.lower()

    # Identify dynamic columns safely
    ese_col = [c for c in df_direct.columns if c in ['ese', 'or', 'oral']]
    rev_cols = [c for c in df_direct.columns if 'review' in c or 'tw' in c or 'termwork' in c]

    ese_series = pd.to_numeric(df_direct[ese_col[0]], errors='coerce') if ese_col else pd.Series(dtype=float)
    rev_series_list = [pd.to_numeric(df_direct[c], errors='coerce') for c in rev_cols]

    d_high = base_threshold / 100.0
    d_mid  = (base_threshold - 15) / 100.0
    d_low  = (base_threshold - 30) / 100.0

    # Attainment Formula for Project (80% ESE / OR) and 20% (Review1/Review2/TW avg)
    ese_att = compute_direct_attainment(ese_series, d_low, d_mid, d_high) if not ese_series.empty else 0.0
    rev_atts = [compute_direct_attainment(ser, d_low, d_mid, d_high) for ser in rev_series_list]
    avg_rev_att = safe_avg(*rev_atts) if rev_atts else 0.0

    if not ese_series.empty and rev_series_list:
        final_dir_att = (0.8 * ese_att) + (0.2 * avg_rev_att)
    elif not ese_series.empty:
        final_dir_att = ese_att
    elif rev_series_list:
        final_dir_att = avg_rev_att
    else:
        final_dir_att = 0.0

    dir_vals = np.array([final_dir_att] * num_theory_cos)
    ind_vals = np.zeros(num_theory_cos) # Projects do not have survey upload

    is_future_year = academic_year >= '2025-26' if academic_year else False
    po_pso_columns = ['PO1','PO2','PO3','PO4','PO5','PO6','PO7','PO8','PO9','PO10','PO11','PO12','PSO1','PSO2','PSO3']
    if is_future_year and 'PO12' in po_pso_columns:
        po_pso_columns.remove('PO12')

    dashboard_results = []
    
    for col in po_pso_columns:
        if col not in df_map.columns: continue
        
        raw_vals = theory_rows[col].values[:num_theory_cos]
        weights_list = []
        applicable_cos_count = 0
        
        for v in raw_vals:
            parsed_val = parse_mapping_value(v)
            if parsed_val is not None and parsed_val > 0:
                weights_list.append(parsed_val)
                applicable_cos_count += 1
            else:
                weights_list.append(0.0)

        weights_array = np.array(weights_list)
        if len(weights_array) < num_theory_cos:
            weights_array = np.pad(weights_array, (0, num_theory_cos - len(weights_array)))

        sum_weights = np.sum(weights_array)

        if applicable_cos_count == 0 or sum_weights <= 0:
            dashboard_results.append({'po': col, 'target': '0.00', 'direct': '0.0000', 'indirect': '0.0000', 'final': '0.0000', 'percentage': '0.00'})
            continue

        target      = sum_weights / applicable_cos_count
        direct_po   = np.sum(dir_vals  * weights_array) / sum_weights if sum_weights > 0 else 0
        
        final_po   = direct_po
        percentage = (final_po / target) * 100 if target > 0 else 0

        dashboard_results.append({
            'po': col, 'target': f"{target:.2f}", 'direct': f"{direct_po:.4f}",
            'indirect': "0.0000", 'final': f"{final_po:.4f}", 'percentage': f"{percentage:.2f}"
        })

    co_statements, practical_statements = extract_statements(df_map, co_col, num_theory_cos, 'no', po_pso_columns, dir_vals, ind_vals, is_project=True)
    return dashboard_results, df_map, df_direct, pd.DataFrame(), co_statements, practical_statements

# ===========================================================================
# STATEMENT EXTRACTION TOOL
# ===========================================================================
def extract_statements(df_map, co_col, num_theory_cos, has_practical, po_pso_columns, dir_vals, ind_vals, is_project=False, direct_only=False, practical_only=False):
    co_statements = []
    practical_statements = []
    
    target_col = [c for c in df_map.columns if 'TARGET' in str(c).upper()]
    t_col = [c for c in df_map.columns if 'THEORY' in str(c).upper() and 'STATEMENT' in str(c).upper()]
    p_col = [c for c in df_map.columns if 'PRACTICAL' in str(c).upper() and 'STATEMENT' in str(c).upper()]
    m_col = [c for c in df_map.columns if 'MAPPED' in str(c).upper() or 'MAP' in str(c).upper()]
    s_col = [c for c in df_map.columns if 'STATEMENT' in str(c).upper() and c not in t_col and c not in p_col]

    theory_idx = 0
    for index, row in df_map.iterrows():
        co_code = str(row[co_col]).strip()
        is_theory = co_code.upper().startswith('C')
        
        if is_theory and theory_idx < num_theory_cos:
            mappings = {}
            for col in po_pso_columns:
                if col in df_map.columns:
                    val = row[col]
                    parsed_val = parse_mapping_value(val)
                    if parsed_val is not None:
                        mappings[col] = str(int(parsed_val))
                    else:
                        mappings[col] = '-'
                else: 
                    mappings[col] = '-'

            if practical_only and p_col:
                stmt = str(row[p_col[0]]).strip() if pd.notna(row[p_col[0]]) else "-"
            elif has_practical == 'yes' and t_col:
                stmt = str(row[t_col[0]]).strip() if pd.notna(row[t_col[0]]) else "-"
            else:
                stmt = str(row[s_col[0]]).strip() if s_col and pd.notna(row[s_col[0]]) else "-"
                
            d_val = dir_vals[theory_idx] if theory_idx < len(dir_vals) else 0.0
            i_val = ind_vals[theory_idx] if theory_idx < len(ind_vals) else 0.0
            
            # New POs and project/termwork paths are direct-only. Old POs retain 80:20.
            f_val = d_val if (is_project or direct_only) else (0.8 * d_val) + (0.2 * i_val)
            
            t_val = 2.50
            if target_col and pd.notna(row[target_col[0]]):
                try: t_val = float(row[target_col[0]])
                except: pass

            co_statements.append({
                'code': co_code, 'statement': stmt if stmt and stmt.lower() != 'nan' else "-",
                'target': f"{t_val:.2f}", 'direct': f"{d_val:.4f}", 'indirect': f"{i_val:.4f}",
                'final': f"{f_val:.4f}", 'mappings': mappings
            })
            theory_idx += 1
            
        if has_practical == 'yes' and not practical_only and p_col:
            p_stmt = str(row[p_col[0]]).strip()
            if p_stmt and p_stmt.lower() not in ['nan', '-', '', 'na']:
                mapped_co = "-"
                if m_col and pd.notna(row[m_col[0]]):
                    val = str(row[m_col[0]]).strip()
                    if val.lower() not in ['nan', '']: mapped_co = val
                practical_statements.append({'statement': p_stmt, 'mapped_to': mapped_co})

    return co_statements, practical_statements

# ===========================================================================
# FLASK ROUTES
# ===========================================================================

@app.route('/')
def home():
    if 'user' in session: return redirect(url_for('attainment_page'))
    return render_template('login.html')

@app.route('/generate_survey_template', methods=['GET', 'POST'])
def generate_survey_template_route():
    try:
        mapping_file = request.files.get('mapping_file') if request.method == 'POST' else None
        if mapping_file and getattr(mapping_file, 'filename', ''):
            co_codes = extract_cos_from_mapping(mapping_file)
        else:
            po_format = request.args.get('po_format', 'old_pos')
            co_count = request.args.get('co_count')
            if co_count:
                try:
                    count = int(co_count)
                    co_codes = [f"CO{i+1}" for i in range(count)]
                except Exception:
                    co_codes = ["CO1", "CO2", "CO3", "CO4", "CO5", "CO6"]
            elif po_format == 'new_pos':
                static_file = os.path.join(app.static_folder, 'mapping_new_pos_template.csv')
                co_codes = extract_cos_from_mapping(static_file) if os.path.isfile(static_file) else ["C410A.1", "C410A.2", "C410A.3", "C410A.4", "C410A.5"]
            elif po_format == 'old_pos_11':
                static_file = os.path.join(app.static_folder, 'mapping_11po_template.csv')
                co_codes = extract_cos_from_mapping(static_file) if os.path.isfile(static_file) else ["C410A.1", "C410A.2", "C410A.3", "C410A.4", "C410A.5", "C410A.6"]
            else:
                static_file = os.path.join(app.static_folder, 'mapping_template.csv')
                co_codes = extract_cos_from_mapping(static_file) if os.path.isfile(static_file) else ["C410A.1", "C410A.2", "C410A.3", "C410A.4", "C410A.5", "C410A.6"]

        csv_content = generate_survey_template_csv(co_codes)
        filename = f"indirect_survey_template_{len(co_codes)}cos.csv"
        return Response(
            csv_content,
            mimetype="text/csv; charset=utf-8",
            headers={"Content-Disposition": f"attachment; filename={filename}"}
        )
    except Exception as e:
        return f"<div style='text-align:center; margin-top:50px;'><h2 style='color:red;'>Template Generation Error</h2><p>{str(e)}</p><a href='/attainment'>Go Back</a></div>", 400

@app.route('/login', methods=['GET', 'POST'])
def login_page():
    error = None
    if request.method == 'POST':
        email = request.form.get('email', '').strip()
        password = request.form.get('password', '').strip()

        if email in ADMIN_EMAILS and password == ADMIN_PASSWORD:
            session.permanent = True
            session['user'] = email
            session['role'] = 'admin'
            return redirect(url_for('attainment_page'))
            
        elif email in TEACHER_ACCOUNTS and password == TEACHER_PASSWORD:
            session.permanent = True
            session['user'] = email
            session['role'] = 'user'
            return redirect(url_for('attainment_page'))
            
        else:
            error = "Invalid Email or Password. Please try again."

    return render_template('login.html', error=error)

@app.route('/logout')
def logout():
    session.pop('user', None)
    session.pop('role', None)
    return redirect(url_for('login_page'))

@app.route('/attainment')
def attainment_page():
    if 'user' not in session: return redirect(url_for('login_page'))
    if session.get('role') not in ['admin', 'user']:
        return "<h2 style='color:red; text-align:center; margin-top:50px;'>Access Denied</h2>"
    return render_template('upload_form.html')

@app.route('/upload', methods=['POST'])
def upload_files():
    if 'user' not in session or session.get('role') not in ['admin', 'user']:
        return redirect(url_for('home'))

    try:
        teacher_name  = request.form.get('teacher_name')
        subject       = request.form.get('subject')
        class_name    = request.form.get('class_name', '').strip()
        class_key     = class_name.upper()
        lab_name      = request.form.get('lab_name', '').strip()
        base_threshold = int(request.form.get('threshold', 80))
        has_practical = request.form.get('has_practical', 'no').strip().lower()
        po_format     = request.form.get('po_format', 'old_pos')
        academic_year = request.form.get('academic_year', '')
        
        # New Field check
        course_type   = request.form.get('course_type', 'theory').strip().lower()
        is_project = (course_type == 'project')
        is_practical_only = (course_type == 'practical')

        # Exact class matching prevents 'TY B TECH' from being mistaken for 'TE'.
        is_te_be = class_key in {'TE', 'BE'}
        is_future_year = academic_year >= '2025-26' if academic_year else False

        mapping_file  = request.files['mapping_file']
        direct_file   = request.files['direct_file']
        
        # New POs no longer require a survey upload. Old PO formats keep it.
        indirect_file = request.files.get('indirect_file')

        if is_practical_only and po_format != 'new_pos':
            raise ValueError('Only Practical evaluation is currently supported with New POs (From 2025-26). Please select New POs.')

        if is_project:
            if not academic_year: academic_year = "2024-25"
            results, df_map, df_direct, df_survey, co_statements, practical_statements = calculate_dashboard_project(
                mapping_file, direct_file, base_threshold, academic_year)
                
        elif po_format == 'old_pos_11' or (po_format == 'old_pos' and is_future_year and is_te_be):
            if not academic_year: academic_year = "2025-26"
            results, df_map, df_direct, df_survey, co_statements, practical_statements = calculate_dashboard_old_pos(
                mapping_file, direct_file, indirect_file, base_threshold, has_practical, exclude_po12=True)
                
        elif po_format == 'old_pos':
            if not academic_year: academic_year = "2024-25"
            results, df_map, df_direct, df_survey, co_statements, practical_statements = calculate_dashboard_old_pos(
                mapping_file, direct_file, indirect_file, base_threshold, has_practical, exclude_po12=False)
                
        else:
            if not academic_year: academic_year = "2025-26"
            results, df_map, df_direct, df_survey, co_statements, practical_statements = calculate_dashboard_new_pos(
                mapping_file, direct_file, base_threshold, has_practical, practical_only=is_practical_only)

        df_map     = df_map.loc[:, ~df_map.columns.astype(str).str.contains('UNNAMED', case=False, na=False)]
        df_direct  = df_direct.loc[:, ~df_direct.columns.astype(str).str.contains('UNNAMED', case=False, na=False)]
        
        mapping_html  = df_map.fillna('-').to_html(classes='raw-table', index=False)
        direct_html   = df_direct.fillna('-').to_html(classes='raw-table', index=False)
        
        if not df_survey.empty:
            df_survey = df_survey.loc[:, ~df_survey.columns.astype(str).str.contains('UNNAMED', case=False, na=False)]
            indirect_html = df_survey.fillna('-').to_html(classes='raw-table', index=False)
        else:
            indirect_html = ""

        return render_template(
            'dashboard.html',
            results=results,
            teacher=teacher_name,
            academic_year=academic_year,
            subject=subject,
            class_name=class_name,
            lab_name=lab_name,
            mapping_html=mapping_html,
            direct_html=direct_html,
            indirect_html=indirect_html,
            co_statements=co_statements,
            practical_statements=practical_statements,
            is_project=is_project,
            course_type=course_type,
            is_direct_only=(is_project or po_format == 'new_pos'),
            show_indirect=(not is_project and po_format != 'new_pos'),
            direct_formula_tooltip=(
                'Only Practical: 75% × ESE + 25% × the CO-aligned CCE score; for CCE-only courses, use the corresponding CCE1–CCE5 score for each CO.'
                if is_practical_only else
                ('New POs: 75% × ESE + 25% × CCE; no indirect survey component.' if po_format == 'new_pos' else 'Existing assessment formula for the selected PO format.')
            )
        )

    except Exception as e:
        traceback.print_exc()
        return f"<div style='text-align:center; margin-top:50px;'><h2 style='color:red;'>Oops! Data Error</h2><p>{str(e)}</p><a href='/attainment' style='padding:10px 20px; background:#007bff; color:white; text-decoration:none; border-radius:5px;'>Try Again</a></div>"

if __name__ == '__main__':
    app.run(debug=False)