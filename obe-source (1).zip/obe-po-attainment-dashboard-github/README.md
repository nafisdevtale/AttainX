# Smart CO PO AttainX — OBE PO Attainment Dashboard

A Flask-based college project for CO–PO/PSO mapping, direct and indirect attainment calculations, and dashboard generation.

## Stack

- Python 3.12
- Flask 3.0.0
- Pandas 2.1.4
- NumPy 1.26.2

## Run locally

```bash
python3.12 -m venv .venv
source .venv/bin/activate
python -m pip install --upgrade pip
python -m pip install -r requirements.txt
python app.py
```

Open `http://127.0.0.1:5000`.

## Deploy to Vercel

This repository is configured for Vercel's Python/Flask runtime. Import the GitHub repository in Vercel, keep the root directory at the repository root, and allow automatic framework detection. The `vercel.json` file sets the Flask function's maximum duration to 60 seconds.

Configure these environment variables in Vercel for Production (and Preview if needed):

| Variable | Purpose |
|---|---|
| `SECRET_KEY` | Long, randomly generated Flask session secret |
| `TEACHER_PASSWORD` | Shared password for the teacher accounts currently listed in `app.py` |
| `ADMIN_EMAILS` | Optional comma-separated administrator email addresses |
| `ADMIN_PASSWORD` | Administrator password; required when `ADMIN_EMAILS` is set |

Generate a secret with:

```bash
python -c "import secrets; print(secrets.token_urlsafe(48))"
```

Do not commit `.env` files or real credentials. The application limits upload requests to 4 MB to remain within Vercel's function request-body limit.

## Data and storage note

Uploaded CSVs are processed in the request and are not stored as a permanent student-record database. Vercel function storage is ephemeral; use an external storage/database service before extending the application to retain student data.

## Attainment calculation rules

For standard theory/practical courses, the final CO and PO score uses a fixed 80:20 blend:

- Direct contribution = direct attainment score × 0.80
- Indirect contribution = indirect survey attainment score × 0.20
- Final attainment = direct contribution + indirect contribution

The selectable target threshold (80%, 70%, 60%, or 50%) is a separate marks-classification setting; it does not change the 80:20 blend. The displayed PO target-achievement percentage is capped at 100%, while the numerical final attainment score remains unchanged so over-target performance is not discarded. Project/termwork/seminar courses continue to use their direct-only overall attainment path.
